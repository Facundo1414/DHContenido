package com.c2.ClinicaOdontologica.entities;

public enum AppUserRoles {
    ROLE_USER,ROLE_ADMIN
}
