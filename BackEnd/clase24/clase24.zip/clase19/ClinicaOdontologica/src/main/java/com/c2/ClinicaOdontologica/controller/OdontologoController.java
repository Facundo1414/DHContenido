package com.c2.ClinicaOdontologica.controller;


import com.c2.ClinicaOdontologica.entities.Odontologo;
import com.c2.ClinicaOdontologica.service.OdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/odontologo")
public class OdontologoController {
    @Autowired
    private OdontologoService odontologoService;

    @GetMapping("/{id}")
    public ResponseEntity<Optional<Odontologo>> buscarOdontologobyId(@PathVariable Long id){
        return ResponseEntity.ok(odontologoService.buscarPorId(id));
    }
    @GetMapping("/{matricula}")
    public ResponseEntity<Optional<Odontologo>> buscarOdontologobyId(@PathVariable String matricula){
        return ResponseEntity.ok(odontologoService.buscarPorMatricula(matricula));
    }
    @PostMapping
    public ResponseEntity<Odontologo> registrarOdontologo(@RequestBody Odontologo odontologo){
        return ResponseEntity.ok(odontologoService.registrarOdontologo(odontologo));
    }
    @PutMapping
    public ResponseEntity<String> actualizarOdontologo(@RequestBody Odontologo odontologo){
        Optional<Odontologo> odontologoBuscado  = odontologoService.buscarPorId(odontologo.getId());
        if (odontologoBuscado.isPresent()){
            odontologoService.registrarOdontologo(odontologo);
            return ResponseEntity.ok("Odontologo Actualizado");
        }
        else {
            return ResponseEntity.badRequest().body("Odontologo no encontrado");
        }
    }



    @GetMapping("/todos")
    public ResponseEntity<List<Odontologo>> buscarTodos(){
        return ResponseEntity.ok(odontologoService.listarTodos());
    }



    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarOdontologo(@PathVariable Long id){
        Optional<Odontologo> odontologoBuscado  = odontologoService.buscarPorId(id);
        if (odontologoBuscado.isPresent()){
            odontologoService.eliminarOdontologo(id);
            return ResponseEntity.ok("Odontologo Eliminado");
        }
        else {
            return ResponseEntity.badRequest().body("Odontologo no encontrado");
        }
    }

}
