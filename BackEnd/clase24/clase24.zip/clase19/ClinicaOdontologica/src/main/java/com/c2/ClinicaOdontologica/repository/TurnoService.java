package com.c2.ClinicaOdontologica.repository;

public interface TurnoService {
}
