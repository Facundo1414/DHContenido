package com.c2.ClinicaOdontologica.service;

public class TurnoService {
}
