package NegocioComidas;

public class MenuClasico extends Menu{
//    ● Menú clásico: no tiene recargos.

    public MenuClasico(double precioBase) {
        super(precioBase,"MenuClasico");

    }

}
