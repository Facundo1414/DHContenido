package NegocioComidas;

public class MenuInfantil extends Menu{
// ● Menú infantil: 3 pesos adicionales por cada juguete incluido.



    public MenuInfantil(double precioBase) {
        super(precioBase + 3,"MenuInfantil");
    }

}
